# gmod-loadingscreen
new fresh dark transparent loading screen.

I've worked on this for a few days for a friend, but he decided to cancel his gmod server, so I didn't want my work wasted, I hope anyone finds this usefull, it did take some hard work.

Please don't reupload or take credits for this.

Feel free te edit and use however you please ;)


# Usage
1) Look at js/config.js for all configurable options
2) Get yourself a web host
3) Use [docs](https://wiki.garrysmod.com/page/Loading_URL) for configuring a loading screen in your Gmod server

# Examples
Live demo at https://lyr-7d1h.github.io/gmod-loadingscreen/

![Image of Loadingscreen](https://i.imgur.com/LYpx95u.png)
